var library = {
  start: [
  'img/Babis.png',
  'img/Adamova.png',
  'img/Sobotka.png',
  'img/Zeman.png',
  'img/Feri.png',
  'img/Havlicek.png',
  'img/Okamura.png',
  'img/Topolanek.png',
  'img/Prymula.png',
  'img/Schwarzenberg.png',
  'img/Babis.png',
  'img/Adamova.png',
  'img/Sobotka.png',
  'img/Zeman.png',
  'img/Feri.png',
  'img/Havlicek.png',
  'img/Okamura.png',
  'img/Topolanek.png',
  'img/Prymula.png',
  'img/Schwarzenberg.png']
  };

var images = [],
tempElt1 = "",
tempElt2 = "",
click = -1,
win = 0,
score = 0,
time = 0;

var preElt = document.querySelector("#pre"),
themesElt = document.querySelector("#themes"),
boxElts = document.getElementsByClassName("box"),
mainElt = document.querySelector(".main"),
timeElt = document.querySelector("#time"),
scoreElt = document.querySelector("#score"),
postElt = document.querySelector("#post"),
finalElt = document.querySelector("#final"),
againElt = document.querySelector("#again");


// Začne hru
themesElt.addEventListener("click", function (e) {
  if (e.target.classList.contains("themes")) {
    activateTheme(e.target.id);
    preElt.classList.add("hidden");
  }
});

function activateTheme(theme) {
  switch (theme) {
    case "start":
      for (let i = 0; i < 20; i++) {images.push(library.start[i]);}
      break;}

  // Vloží obrázky
  for (let i = 0; i < 20; i++) {
    var rand = Math.floor(Math.random() * (images.length - 1));
    boxElts[i].innerHTML = "<img src='" + images[rand] + "' alt='image' class='hidden'>";
    images.splice(rand, 1);
  }
}

mainElt.addEventListener("click", gameLogic);

function gameLogic(e) {
  if (e.target.classList.contains("play")) {
    e.target.firstChild.classList.remove("hidden");
    // První klik
    if (click < 1) {
      tempElt1 = e.target;
      // Časovač
      if (click === -1) {
        timer = setInterval(function () {
          time++;
          timeElt.innerHTML = time;
        }, 1000);
      }
      click = 1;
    }

    // Sekundární klik
    else if (e.target !== tempElt1) {
        tempElt2 = e.target;

        // Odlišné obrázky
        if (tempElt1.firstChild.src !== tempElt2.firstChild.src) {
          mainElt.removeEventListener("click", gameLogic);
          setTimeout(function () {
            tempElt1.firstChild.classList.add("hidden");
            tempElt2.firstChild.classList.add("hidden");
            mainElt.addEventListener("click", gameLogic);
          }, 400);
		  
			var audio = new Audio('audio/nope.mp3');
			audio.play();
		  
          if (score > 0) {
            score -= 1;
			
          }
          scoreElt.innerHTML = score;
        }

        // Stejné obrázky
        else {
            score += 2;
			
			var audio = new Audio('audio/wow.mp3');
			audio.play();
			
            win += 2;
            tempElt1.firstChild.classList.add("outlined");
            tempElt2.firstChild.classList.add("outlined");
            tempElt1.classList.remove("play");
            tempElt2.classList.remove("play");
            scoreElt.innerHTML = score;

            // Vyhraná hra
            if (win === 20) {
              clearTimeout(timer);
              finalElt.innerHTML = "Vyhrál jsi s " + score + " body <br> v čase " + time + " sekund";
              postElt.classList.remove("hidden");
            }
          }
        click = 0;
      }
  }
}

againElt.addEventListener("click", resetGame);

function resetGame() {
  // Vyresetuje hru
  tempElt1 = "";
  tempElt2 = "";
  click = -1;
  win = 0;
  score = 0;
  time = 0;
  postElt.classList.add("hidden");
  preElt.classList.remove("hidden");
  for (let i = 0; i < 20; i++) {
    boxElts[i].classList.add("play");
    boxElts[i].firstChild.classList.add("hidden");
  }
  timeElt.textContent = time;
  scoreElt.textContent = score;
}

function togglePlay() {
  var myAudio = document.getElementById("myAudio");
  return myAudio.paused ? myAudio.play() : myAudio.pause();
};

window.onload = function() {
    document.getElementById("myAudio").play();
}